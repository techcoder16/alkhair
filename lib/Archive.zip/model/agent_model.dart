
// ignore_for_file: non_constant_identifier_names

class Agent
{


 final String  id;
 final String dst_code;
 final String distributor_type;
 final String name;
 final String shop_name;
 final String email;
 final String  avatar;
 final String shop_size;
 final String floor;
 final String owned;
 final String covered_sale;
 final String uncovered_sale;
 final String total_sale;
 final String credit_limit;
 final String companies_working_with;
 final String working_with_us;
 final String our_brands;
 final String cnic;
 final String contact_no_1;
 final String contact_no_2;
 final String address;
 final String city;
 final String coordinates;
 final String api_token;
 final String password_string;
 final String password;
 final String email_verified_at;
 final String remember_token;
 final String status;
 final String deleted_by;
 final String deleted_at;
 final String updated_by;
 final String added_by;
 final String created_at;
 final String updated_at;
 final String width;
 final String depth;




 Agent(



      this.id,
      this.dst_code,
      this.distributor_type,
      this.name,
      this.shop_name,
      this.email,
      this.avatar,
      this.shop_size,
      this.floor,
      this.owned,
      this.covered_sale,
      this.uncovered_sale,
      this.total_sale,
      this.credit_limit,
      this.companies_working_with,
      this.working_with_us,
      this.our_brands,
      this.cnic,
      this.contact_no_1,
      this.contact_no_2,
      this.address,
      this.city,
      this.coordinates,
      this.api_token,
      this.password_string,
      this.password,
      this.email_verified_at,
      this.remember_token,
      this.status,
      this.deleted_by,
      this.deleted_at,
      this.updated_by,
      this.added_by,
      this.created_at,
      this.updated_at, this.width,
     this.depth,



     );
 /*

 factory Agent.fromJson(Map<String, dynamic> parsedJson) {
  return  Agent(

   id:parsedJson['id']?? " ",
   dst_code:    parsedJson['dst_code']?? " ",
   distributor_type:parsedJson['dst_code']?? " ",
   name:  parsedJson['name ']?? " ",
   shop_name:  parsedJson['shop_name']?? " ",
   email:  parsedJson['email']?? " ",
   avatar:  parsedJson['avatar']?? " ",
   shop_size:  parsedJson['shop_size']?? " ",
   floor:  parsedJson['floor']?? " ",
   owned:  parsedJson['owned']?? " ",
   covered_sale:  parsedJson['covered_sale']?? " ",
   uncovered_sale:  parsedJson['uncovered_sale'] ?? " ",
   total_sale:  parsedJson['total_sale'] ?? " ",
   credit_limit:  parsedJson['credit_limit'] ?? " ",
   companies_working_with:  parsedJson['companies_working_with'] ?? " ",
   working_with_us :  parsedJson['working_with_us'] ?? " ",
   our_brands :  parsedJson['our_brands'] ?? " ",
   cnic :  parsedJson['cnic'] ?? " ",
   contact_no_1 :  parsedJson['contact_no_1'] ?? " ",
   contact_no_2 :  parsedJson['contact_no_2'] ?? " ",
   address :  parsedJson['address']  ?? " ",
   city :  parsedJson['city'] ?? " ",
   coordinates :  parsedJson['coordinates'] ?? " ",
   api_token :  parsedJson['api_token'] ?? " ",
   password_string :  parsedJson['password_string'] ?? " ",
   password :  parsedJson['password'] ?? " ",
   email_verified_at :  parsedJson['email_verified_at' ?? " ",,
   remember_token :  parsedJson['remember_token'] ?? " ",
   status :  parsedJson['status'] ?? " ",
   deleted_by :  parsedJson['deleted_by'] ?? " ",
   deleted_at :  parsedJson['deleted_at'] ?? " ",
   updated_by :  parsedJson['updated_by'] ?? " ",
   added_by :  parsedJson['added_by'] ?? " ",
   created_at :  parsedJson['created_at'] ?? " ",
   updated_at :  parsedJson['updated_at'] ?? " ",


  );*/


 //}



/*
 Map<String, dynamic> toJson() {
  return {
"id": this.id,
"dst_code": this.dst_code,
"distributor_typ": this.distributor_type,
"name": this.name,
"shop_name": this.shop_name,
"email": this.email,
"avatar": this.avatar,
"shop_size": this.shop_size,
"floor": this.floor,
"owned": this.owned,
"covered_sale": this.covered_sale,
"uncovered_sale": this.uncovered_sale,
"total_sale": this.total_sale,
"credit_limit": this.credit_limit,
"companies_worki": this.companies_working_with,
"working_with_us": this.working_with_us,
"our_brands": this.our_brands,
"cnic": this.cnic,
"contact_no_1": this.contact_no_1,
"contact_no_2": this.contact_no_2,
"address": this.address,
"city": this.city,
"coordinates": this.coordinates,
"api_token": this.api_token,
"password_string": this.password_string,
"password": this.password,
"email_verified_": this.email_verified_at,
"remember_token": this.remember_token,
"status": this.status,
"deleted_by": this.deleted_by,
"deleted_at": this.deleted_at,
"updated_by": this.updated_by,
"added_by": this.added_by,
"created_at": this.created_at,
"updated_at": this.updated_at,

  };


 }



 void saveDataDistributor(

 'distributor_type': '2',
 'name':                                           distributor,
 'shop_name':                                       shop,
 'email':                                           email,
 'cnic':                                          cnic,
 'address':                                          address,
 'city':                                            city,
 'coordinates':                                     coordinates.toString(),
 'added_by':                                       id.toString(),
 'shop_size':                                     shopsize,
 'floor':                                             floor,
 'owned':                                                  '1',
 'covered_sale':                                      sale,
 'uncovered_sale':                                       usales,
 'total_sale':                                             totalSales,
 'credit_limit':                                              card,
 'companies_working_with':                                    companies,
 'working_with_us':                                    value_check_2 == true ? "1" : "0",
 "our_brands":                                      _value_brand_param,

 'contact_no_1':                                      contactNo,
 'contact_no_2':                                   contactt,
 'password':                                       "000000",
 "password_confirmation":                             "000000",
 'added_by':                     id,

     )
 {



 }



*/



}