library my_prj.globals;
double currentlattitude = 0;
double currentlongitude = 0;

String location_key = "";

