var base_Url = "http://alkhair.hameedsweets.com/";
